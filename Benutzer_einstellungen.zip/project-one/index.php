<?php
/**
 * Created by PhpStorm.
 * User: dray6
 * Date: 16.10.2018
 * Time: 07:36
 */


//  Write the application name
echo "
\n################################################################
\n######################### SYSTEM LOGIN #########################
\n################################################################";

// Show the available manu
$menus =array(
    "neu Benutzer erstellen",
    "Read all user", 
    "Show total users" ,
    "Delete the user", 
    "Exit"
);

echo "\nSelect the menu";
foreach($menus as $menuNo => $menu){
    echo "\n " .  $menuNo . "  =>  " .  $menu;
}

// print space 
echo("\n\n");

// get the user 
$menuSelected = readline("Enter the menu No\n");

switch($menuSelected){
    case 0 : 
        // New user
        createNewUser();
        break;
    case 1 :
        // show all User
        showAllUsers();
        break;
    case 2 : 
        // Exit
        showTotalUsersCount();
        break;
    case 3 : 
        // Exit
        deleteTheUserForName();
        break;        
    case 4 : 
        // Exit
        printBeautifulText("GOOD BYE");
        break; }

/* 
    FUNCTIONS 
*/
function printBeautifulText($cotent){
    echo "\n*************************  " . $cotent . "  ***********************";
}


function fileIsExist() : bool{
    if (file_exists('users.json')) {
         return true;
    } else {
        $userdata = [];
        echo "There is no file..";
        return false;
    }
}

function createNewUser(){
    $usersArray = readUsersFromJsonFileAsArray();
    $name = readline("Please enter your name to create new user!");
    if(!empty($name)){
        $arrne['name'] = $name;
        array_push($usersArray, $arrne );
        file_put_contents('users.json', json_encode($usersArray));
        printBeautifulText("SUCCESFULLY CREATED");
    }else{
        printBeautifulText("Sorry, Name can not be empty");
    }
    
}

function readUsersFromJsonFileAsArray() : array{
    $usersJson = file_get_contents('users.json');
    $usersArray = json_decode($usersJson, true);
    
    return $usersArray;
}

function showTotalUsersCount(){
    $usersArray = readUsersFromJsonFileAsArray();
    printBeautifulText("TOTAL USERS = " . count($usersArray));
}

function showAllUsers(){
    $usersArray = readUsersFromJsonFileAsArray();
    foreach($usersArray as $no => $name){
        echo "\n " .  $no . "  =>  " .  $name['name'];
    }
}

function deleteTheUserForName(){
    $name = readline("Please enter your name to delete! -   ");
    if(empty($name)){
        $usersArray = readUsersFromJsonFileAsArray();
        $found = false;
        foreach($usersArray as $username){
            if($username == $name){
                unset($usersArray,  $name);
                $found = true;
                printBeautifulText("User Removed");
                break;
            }
         
        }
    
        if(!$found){
            printBeautifulText("Sorry, No any user with this name");
        }
    }else{
        printBeautifulText("Sorry, Name can not be empty");
    }
}

// function validateName() : bool{
//     $name = strtolower(readline("Please enter your name of the user to delete"));
//     if(empty($name)){
//         printBeautifulText("Please enter valid name, name can not be empty");
//         return false; 
//     }

//     return true;
// }







